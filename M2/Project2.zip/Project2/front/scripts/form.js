const axios = require("axios");

document.getElementById("resetButton").addEventListener("click", () => {
  document.getElementById("movieForm").reset();
});

document
  .getElementById("movieForm")
  .addEventListener("submit", async (event) => {
    event.preventDefault();

    const title = document.getElementById("title").value.trim();
    const year = document.getElementById("year").value.trim();
    const director = document.getElementById("director").value.trim();
    const duration = document.getElementById("duration").value.trim();
    const genre = document.getElementById("genre").value.trim();
    const genresArray = genre.split(",").map((genre) => genre.trim());
    const rate = document.getElementById("rate").value.trim();
    const poster = document.getElementById("poster").value.trim();

    if (
      !title ||
      !year ||
      !director ||
      !duration ||
      !genre ||
      !rate ||
      !poster
    ) {
      alert("Por favor, completa todos los campos.");
      return;
    }

    // Validando el formato del año
    if (!/^\d{4}$/.test(year)) {
      alert("El año debe tener 4 dígitos.");
      return;
    }

    // Validando que la calificación esté entre 0 y 10
    if (rate < 0 || rate > 10) {
      alert("La calificación debe estar entre 0 y 10.");
      return;
    }

    // En este punto, podrías enviar los datos a tu backend o hacer otra acción. Datos listos para enviar
    /*   const submitButton = document.getElementById("submit__button");
  submitButton?.addEventListener("click", form);
  alert("Formulario enviado correctamente.");*/

    const movieData = { title, year, director, duration, genre, rate, poster };

    // Aquí puedes enviar los datos al backend con Axios o fetch
    try {
      const response = await axios.post("/api/movies", movieData);
      alert("Película enviada correctamente.");
      document.getElementById("movieForm").reset();
    } catch (error) {
      console.error("Error al enviar la película:", error);
      alert("Hubo un error al enviar la película. Intenta nuevamente.");
    }
  });
