interface RegisterUserDto {
    name: string
    email: string
    password: string
    address: string
    phone: string
}

export default RegisterUserDto;