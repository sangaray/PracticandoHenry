export interface CreateOrderDto {
  userId: number;
  products: number[];
}
