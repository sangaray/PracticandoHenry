interface LoginUserDto {
    email: string
    password: string
}

export default LoginUserDto;