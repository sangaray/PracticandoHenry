interface CreateCredentialDto {
    password: string;
}

export default CreateCredentialDto;