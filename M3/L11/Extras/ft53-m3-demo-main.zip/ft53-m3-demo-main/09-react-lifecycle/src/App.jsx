import "./App.css";
import ClassCounter from "./components/ClassCounter";
import FunctionCounter from "./components/FunctionCounter";

function App() {
  return (
    <>
      <h1>REACT LifeCycle</h1>
      <hr />
      {/* <ClassCounter /> */}
      <FunctionCounter />
    </>
  );
}

export default App;
