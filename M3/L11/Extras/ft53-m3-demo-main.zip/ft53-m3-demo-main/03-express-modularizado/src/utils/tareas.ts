import ITarea from "../interfaces/Itarea";

//* Simulamos Base de Datos...
export const tareas: ITarea[] = [
  {
    id: 1,
    actividad: "Repasar Express",
    prioridad: 9,
  },
  {
    id: 2,
    actividad: "Repasar TypeScript",
    prioridad: 8,
  },
];