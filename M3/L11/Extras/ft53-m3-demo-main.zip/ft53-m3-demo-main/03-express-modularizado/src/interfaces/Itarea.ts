export default interface ITarea {
  id?: number;
  actividad: string;
  prioridad: number;
}