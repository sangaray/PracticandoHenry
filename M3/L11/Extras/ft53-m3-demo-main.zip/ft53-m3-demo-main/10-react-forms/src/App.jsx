import "./App.css";
import FormikLogin from "./components/FormikLogin";

function App() {
  return (
    <>
      {/* <FormLogin /> */}
      <FormikLogin />
    </>
  );
}

export default App;
