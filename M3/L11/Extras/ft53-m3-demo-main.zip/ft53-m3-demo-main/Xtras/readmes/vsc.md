# Atajos de Visual Studio Code

[Volver a Inicio](../README.md)

### Mover una línea
> Alt + Flecha arriba o abajo

### Copiar una línea
> Alt + Shift + Flecha arriba o abajo

### Borrar una línea
> Ctrl + Shift + K

### Seleccionar todas las apariciones de una palabra
> Ctrl + Shift + L

### Seleccionar varias líneas
> Alt + Click izquierdo

### Seleccionar en forma de cuadrado
> Alt + Shift + Click

### Ajustar código a la ventana
> Alt + Z

### Abrir panel de extensiones
> Ctrl + Shift + W

### Abrir panel de archivos
> Ctrl + Shift + E

### Cerrar todos los paneles
> Ctrl + B

### Crear nuevo archivo
> Ctrl + N

### Cerrar un archivo
> Ctrl + W

### Cerrar todos los archivos
> Ctrl + K + W

<img src="https://uxwing.com/wp-content/themes/uxwing/download/brands-and-social-media/visual-studio-code-icon.png" style="margin: 20px 0 60px 0; width: 100px">
