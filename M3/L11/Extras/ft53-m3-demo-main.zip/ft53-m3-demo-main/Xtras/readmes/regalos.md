[Volver a inicio](../README.md)

## 🎉 REGALOS: FIN DEL MÓDULO 3 ¡¡¡FELICIDADES EQUIPO!!! 🎉🎉🎉

- [Gestión de tiempo - Cuadrantes de Covey](https://lamenteesmaravillosa.com/los-4-cuadrantes-de-stephen-covey-para-gestionar-el-tiempo/)
- [FODA: Fortalezas/Oportunidades Debilidades/Amenazas](foda.md)
- [Código Limpio en JavaScript](https://github.com/andersontr15/clean-code-javascript-es)
- [Toda la Documentación en un solo lugar](https://devdocs.io/)
- [El gran libro de HTML5, CSS3 y JavaScript](https://github.com/jorgegarba/CodiGo8/blob/master/El%20gran%20libro%20de%20HTML5%2C%20CSS3%20y%20JavaScript%20Ed%203.pdf)
- Libros en Inglés sobre nuestro lenguaje favorito:
  - [Eloquent JavaScript](https://eloquentjavascript.net/)
  - [You Dont Know JS](https://github.com/getify/You-Dont-Know-JS)
- Algunas páginas donde poder practicar:
  1. [freeCodeCamp](https://www.freecodecamp.org/): Ofrece un currículum completo de desarrollo web con muchos desafíos de JavaScript interactivos.
  2. [Codewars](https://www.codewars.com/): Te permite resolver desafíos de programación en diferentes niveles de dificultad, lo que te ayudará a mejorar tus habilidades de JavaScript.
  3. [HackerRank](https://www.hackerrank.com/): Tiene una serie de desafíos y tutoriales específicos de JavaScript para que puedas practicar y mejorar.
  4. [LeetCode](https://leetcode.com/): Ofrece problemas de codificación que puedes resolver en JavaScript y en otros lenguajes de programación.
  5. [Exercism](https://exercism.org/): Ofrece ejercicios de programación y revisiones de mentores para ayudarte a aprender y mejorar tus habilidades de JavaScript.
  6. [JSFiddle](https://jsfiddle.net/): Es una herramienta en línea donde puedes escribir, ejecutar y compartir código JavaScript.
  7. [Codecademy](https://www.codecademy.com/): Ofrece un curso interactivo de JavaScript donde puedes aprender y practicar al mismo tiempo.
  8. [Edabit](https://edabit.com/): Proporciona una gran cantidad de desafíos de codificación en JavaScript y otros lenguajes.
  9. [Ejercicios de JavaScript para Navidad 🎄](https://adventjs.dev/es): Un ejercicio de JavaScript para cada día de Diciembre.

## ÉXITOS 💛💛💛
