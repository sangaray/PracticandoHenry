function suma2(a, b) {
  return a + b;
  // 3Hola
}

console.log(suma2(3, "Hola"));