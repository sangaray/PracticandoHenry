import React from "react";
import styles from "../styles/styles.module.css";

const GETCHARACTERBYID_URL = "https://dragonball-api.com/api/characters/";

export default function Detail(props) {
  return (
    <div className={styles.container}>
      <h2>Detalle</h2>
      <hr />
    </div>
  );
}
