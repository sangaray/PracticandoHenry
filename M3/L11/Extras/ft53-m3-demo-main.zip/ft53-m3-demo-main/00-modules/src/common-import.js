//* COMMON JS - Importación
//* En entorno Node JS

const { sumar, num1, num2 } = require("./common-export");

console.log(sumar(num1, num2));
