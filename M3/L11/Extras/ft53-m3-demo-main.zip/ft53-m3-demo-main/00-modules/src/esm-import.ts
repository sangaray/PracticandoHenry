//* ECMAScript Modules - Importación
//* En entorno V8

import porDefault from "./esm-export";
import { lenny, carl } from "./esm-export";

porDefault(lenny);