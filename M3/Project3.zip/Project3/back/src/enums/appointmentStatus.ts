enum AppointmentStatus {
  ACTIVE = "Active",
  CANCELED = "Canceled",
}

export default AppointmentStatus;
