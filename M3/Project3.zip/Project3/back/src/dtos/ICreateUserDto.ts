interface ICreateUserDto {
  name: string;
  email: string;
  birthdate: string;
  nDni: number;
  username: string;
  password: string;
}

export default ICreateUserDto;
