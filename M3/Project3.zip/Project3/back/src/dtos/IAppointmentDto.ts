interface IAppointmentDto {
  date: string; // 2024-12-28
  time: string; // 14:30
  description: string;
  userId: number;
}

export default IAppointmentDto;
