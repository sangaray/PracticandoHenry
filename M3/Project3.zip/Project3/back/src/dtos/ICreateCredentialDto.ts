interface ICreateCredentialDto {
  username: string;
  password: string;
}

export default ICreateCredentialDto;
