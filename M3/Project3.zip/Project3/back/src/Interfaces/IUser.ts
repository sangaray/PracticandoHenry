interface IUser {
  id: number;
  name: string;
  email: string;
  birthdate: string; // o Date
  nDni: number;
  credentialsId: number;
}

export default IUser;
