import "dotenv/config";

export const PORT = process.env.PORT;
