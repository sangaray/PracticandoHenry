import appointmentStatus from "../enums/appointmentStatus";
import IAppointmentDto from "../dtos/IAppointmentDto";
import {
  AppointmentRespository,
  userRepository,
} from "../Repositories/indexRepository";
import { Appointment } from "../entities/AppointmentEntity";

// Servicio para obtener todos los appointments
export const getAllAppointmentsService = async (): Promise<Appointment[]> => {
  const allAppointments: Appointment[] = await AppointmentRespository.find();
  return allAppointments;
};

// Servicio para obtener un appointment por su ID
export const getAppointmentByIdService = async (
  turnId: number
): Promise<Appointment> => {
  const appointment: Appointment | null =
    await AppointmentRespository.findOneBy({ id: turnId });
  if (!appointment) {
    throw new Error("Turno no encontrado");
  }
  return appointment;
};

// Servicio para crear un nuevo appointment
export const createAppointmentService = async (
  IAppointmentDto: IAppointmentDto
): Promise<Appointment> => {
  const { date, time, description, userId } = IAppointmentDto;
  // Hacer validación que no haya dos turnos en el mismo horario a través de un middleware

  // Validaciones básicas
  // 1. Traer al usuario y validar que el usuario exista
  const user = await userRepository.findOneBy({ id: userId });
  if (!user) {
    throw new Error(`No se encontró el usuario con id ${userId}`);
  }
  // 2. Crear un nuevo turno
  const newAppointment: Appointment = AppointmentRespository.create({
    date,
    time,
    description,
  });

  // 3. Asociar el turno con el usuario
  newAppointment.user = user;

  // 4. Guardar el turno en la base de datos
  await AppointmentRespository.save(newAppointment);

  return newAppointment;
};

// Servicio para cancelar un appointment
export const cancelAppointmentService = async (
  turnId: number
): Promise<void> => {
  const appointment: Appointment | null =
    await AppointmentRespository.findOneBy({ id: turnId });
  if (!appointment) {
    throw new Error("Turno no encontrado");
  }
  appointment.status = appointmentStatus.CANCELED;
  await AppointmentRespository.save(appointment);
  return;
};
